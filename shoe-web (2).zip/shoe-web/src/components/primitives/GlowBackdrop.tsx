import { motion } from "framer-motion";

interface GlowBackdropProps {
  className?: string;
}

// Fixed, identical treatment everywhere it's used — same two orbs, same
// positions, same colors — so every dark section reads as one continuous
// environment instead of each section rolling its own random combo.
const ORBS = [
  { color: "var(--color-accent)", position: "left-[-10%] top-[-15%]", duration: 18 },
  { color: "var(--color-coral)", position: "right-[-15%] bottom-[-15%]", duration: 22 },
];

export default function GlowBackdrop({ className = "" }: GlowBackdropProps) {
  return (
    <div className={`pointer-events-none absolute inset-0 overflow-hidden ${className}`}>
      {/* Fine dot-grid texture */}
      <div
        className="absolute inset-0 opacity-[0.15]"
        style={{
          backgroundImage:
            "radial-gradient(circle at 1px 1px, rgba(255,255,255,0.5) 1px, transparent 0)",
          backgroundSize: "28px 28px",
        }}
      />
      {/* Soft drifting glow orbs — fixed pair, consistent everywhere */}
      {ORBS.map((orb, i) => (
        <motion.div
          key={i}
          animate={{ x: [0, 30, -20, 0], y: [0, -20, 20, 0] }}
          transition={{ duration: orb.duration, repeat: Infinity, ease: "easeInOut" }}
          className={`absolute h-[420px] w-[420px] rounded-full blur-3xl ${orb.position}`}
          style={{ background: orb.color, opacity: 0.14 }}
        />
      ))}
    </div>
  );
}
