import { motion } from "framer-motion";
import { shoeVariants } from "./ShoeIllustrations";

interface PhotoBlockProps {
  aspect?: "square" | "portrait" | "landscape";
  label?: string;
  tilt?: number;
  dark?: boolean;
  shoe?: 1 | 2 | 3 | 4;
  accent?: "green" | "gold" | "coral";
  interactive?: boolean;
  className?: string;
}

const aspectClasses: Record<string, string> = {
  square: "aspect-square",
  portrait: "aspect-[3/4]",
  landscape: "aspect-[4/3]",
};

const accentColors: Record<string, string> = {
  green: "var(--color-accent)",
  gold: "var(--color-gold)",
  coral: "var(--color-coral)",
};

export default function PhotoBlock({
  aspect = "square",
  label,
  tilt = 0,
  dark = false,
  shoe = 1,
  accent = "green",
  interactive = false,
  className = "",
}: PhotoBlockProps) {
  const Shoe = shoeVariants[shoe - 1];
  const accentColor = accentColors[accent];

  return (
    <motion.div
      style={tilt ? { transform: `rotate(${tilt}deg)` } : undefined}
      whileHover={interactive ? { y: -6, scale: 1.02 } : undefined}
      transition={{ type: "spring", stiffness: 300, damping: 22 }}
      className={`relative overflow-hidden rounded-card ${aspectClasses[aspect]} ${
        dark ? "bg-ink-soft" : "bg-tile"
      } ${className}`}
    >
      {/* Custom illustrated placeholder — TODO: swap for real product photography */}
      <div
        className="absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage:
            "radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)",
          backgroundSize: "12px 12px",
        }}
      />
      <div
        className="absolute left-1/2 top-1/2 h-[65%] w-[65%] -translate-x-1/2 -translate-y-1/2 rounded-full blur-2xl"
        style={{ background: accentColor, opacity: dark ? 0.25 : 0.18 }}
      />
      <Shoe
        accent={accentColor}
        className="absolute left-1/2 top-1/2 h-auto w-[92%] -translate-x-1/2 -translate-y-1/2 drop-shadow-[0_8px_16px_rgba(0,0,0,0.25)]"
      />
      {label && (
        <span className="absolute bottom-3 left-3 rounded-pill bg-white/95 px-3 py-1 text-body-xs font-medium text-text shadow-float">
          {label}
        </span>
      )}
    </motion.div>
  );
}
