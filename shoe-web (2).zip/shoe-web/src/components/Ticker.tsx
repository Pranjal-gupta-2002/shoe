import { Marquee } from "./ui/marquee";

const TAGLINE = "FRESH DROPS WEEKLY";

export default function Ticker() {
  return (
    <div className="relative overflow-hidden py-4">
      <div
        className="absolute inset-0 opacity-[0.15]"
        style={{
          backgroundImage:
            "radial-gradient(circle at 1px 1px, rgba(255,255,255,0.5) 1px, transparent 0)",
          backgroundSize: "28px 28px",
        }}
      />
      <Marquee pauseOnHover repeat={2} className="relative [--duration:28s]">
        {Array.from({ length: 10 }).map((_, i) => (
          <span
            key={i}
            className="font-display text-lg font-bold uppercase tracking-wide text-accent"
          >
            {TAGLINE} <span className="mx-6 text-white/30">•</span>
          </span>
        ))}
      </Marquee>
    </div>
  );
}
