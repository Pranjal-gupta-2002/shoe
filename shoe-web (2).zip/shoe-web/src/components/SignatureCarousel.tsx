import useEmblaCarousel from "embla-carousel-react";
import { useCallback, useEffect, useState } from "react";
import SectionHeading from "./primitives/SectionHeading";
import PhotoBlock from "./primitives/PhotoBlock";
import GlowBackdrop from "./primitives/GlowBackdrop";
import { signatureShoes } from "../data/products";

export default function SignatureCarousel() {
  const [emblaRef, emblaApi] = useEmblaCarousel({ align: "start", loop: true, dragFree: false });
  const [active, setActive] = useState(0);

  const onSelect = useCallback(() => {
    if (!emblaApi) return;
    setActive(emblaApi.selectedScrollSnap());
  }, [emblaApi]);

  useEffect(() => {
    if (!emblaApi) return;
    onSelect();
    emblaApi.on("select", onSelect);
    emblaApi.on("reInit", onSelect);
  }, [emblaApi, onSelect]);

  return (
    <section className="relative overflow-hidden bg-bg px-4 py-12 md:px-16 md:py-24">
      <GlowBackdrop />
      <div className="relative mx-auto max-w-6xl">
        <SectionHeading eyebrow={`${active + 1} / ${signatureShoes.length}`}>
          Explore Our Signature Shoes
        </SectionHeading>

        <div ref={emblaRef} className="mt-8 overflow-hidden">
          <div className="flex gap-5">
            {signatureShoes.map((name, i) => (
              <div key={name} className="w-56 flex-shrink-0">
                <PhotoBlock
                  aspect="portrait"
                  label={name}
                  shoe={((i % 4) + 1) as 1 | 2 | 3 | 4}
                  accent={(["green", "gold", "coral"] as const)[i % 3]}
                  interactive
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
