import { motion } from "framer-motion";
import { useMemo, useState } from "react";
import SectionHeading from "./primitives/SectionHeading";
import GlowBackdrop from "./primitives/GlowBackdrop";
import ProductCard from "./ProductCard";
import QuickViewModal from "./QuickViewModal";
import { categories, products, type Product, type ProductCategory } from "../data/products";

type Filter = "All" | ProductCategory;

export default function ProductCatalog() {
  const [filter, setFilter] = useState<Filter>("All");
  const [quickView, setQuickView] = useState<Product | null>(null);

  const filtered = useMemo(
    () => (filter === "All" ? products : products.filter((p) => p.category === filter)),
    [filter]
  );

  const filters: Filter[] = ["All", ...categories];

  return (
    <section id="catalog" className="relative overflow-hidden bg-bg px-4 py-12 md:px-16 md:py-24">
      <GlowBackdrop />
      <div className="relative mx-auto max-w-6xl">
        <SectionHeading>Your Everyday Style Upgrade</SectionHeading>
        <p className="mt-3 max-w-md text-body-md text-paper-muted">
          Level up your daily look with shoes that blend comfort, attitude, and effortless style.
        </p>

        <div className="mt-8 flex flex-wrap gap-2">
          {filters.map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => setFilter(f)}
              className="relative rounded-pill px-4 py-2 text-body-sm font-medium"
            >
              {filter === f && (
                <motion.span
                  layoutId="filterActive"
                  className="absolute inset-0 rounded-pill bg-accent"
                  transition={{ type: "spring", stiffness: 400, damping: 30 }}
                />
              )}
              <span className={`relative z-10 ${filter === f ? "text-white" : "text-paper-muted"}`}>
                {f}
              </span>
            </button>
          ))}
        </div>

        <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((product) => (
            <ProductCard key={product.id} product={product} onQuickView={setQuickView} />
          ))}
        </div>
      </div>

      <QuickViewModal product={quickView} onClose={() => setQuickView(null)} />
    </section>
  );
}
