import { motion } from "framer-motion";
import PhotoBlock from "./primitives/PhotoBlock";
import GlowBackdrop from "./primitives/GlowBackdrop";

const wheelWords = [
  { label: "Campaigns", angle: 0 },
  { label: "Beauty", angle: 120 },
  { label: "Lookbook", angle: 240 },
];

const filmstrip = ["Retro Pulse", "Cloud Step", "Hypevibe", "Urban Flex", "Prime Step", "Zenith Kicks"];

export default function LookbookWheel() {
  return (
    <section className="relative overflow-hidden bg-bg px-4 py-16 md:px-16 md:py-24">
      <GlowBackdrop />
      <div className="relative mx-auto flex h-80 w-80 items-center justify-center">
        <PhotoBlock aspect="square" shoe={2} accent="gold" className="h-56 w-56" />

        <motion.div
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 60, ease: "linear" }}
          className="absolute inset-0"
        >
          {wheelWords.map((word) => (
            <div
              key={word.label}
              className="absolute left-1/2 top-1/2"
              style={{ transform: `rotate(${word.angle}deg) translateY(-160px)` }}
            >
              <motion.span
                animate={{ rotate: -360 }}
                whileHover={{ scale: 1.15 }}
                transition={{ rotate: { repeat: Infinity, duration: 60, ease: "linear" } }}
                className="inline-block cursor-pointer text-body-xs font-semibold uppercase tracking-widest text-accent"
              >
                {word.label}
              </motion.span>
            </div>
          ))}
        </motion.div>
      </div>

      <div className="relative mx-auto mt-16 max-w-6xl">
        <h2 className="pointer-events-none absolute inset-x-0 top-1/2 -translate-y-1/2 text-center font-display text-[36px] font-black uppercase text-white/90 md:text-display-lg">
          Shoes That Speak
        </h2>
        <div className="no-scrollbar flex gap-4 overflow-x-auto pb-2 pt-10">
          {filmstrip.map((name, i) => (
            <div key={name} className="w-40 flex-shrink-0">
              <PhotoBlock
                aspect="portrait"
                label={name}
                shoe={((i % 4) + 1) as 1 | 2 | 3 | 4}
                accent={(["green", "gold", "coral"] as const)[i % 3]}
                interactive
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
