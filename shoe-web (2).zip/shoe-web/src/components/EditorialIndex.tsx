import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import PhotoBlock from "./primitives/PhotoBlock";
import GlowBackdrop from "./primitives/GlowBackdrop";

const indexRows = [
  { name: "Vortex Run", number: "01" },
  { name: "KickCraft", number: "02" },
  { name: "EdgeLine", number: "03" },
];

const listingRows = [
  "Midnight Black Smooth Leather",
  "Tan Heritage Leather",
];

export default function EditorialIndex() {
  return (
    <section className="relative overflow-hidden bg-bg px-4 py-12 md:px-16 md:py-24">
      <GlowBackdrop />
      <div className="relative mx-auto max-w-6xl">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-2">
          <PhotoBlock
            aspect="portrait"
            tilt={-2}
            shoe={4}
            accent="coral"
            interactive
            className="max-w-xs"
          />

          <div>
            <h2 className="font-display text-[64px] font-black uppercase leading-none text-white/10 md:text-[96px]">
              CONTENTS
            </h2>
            <ul className="mt-6 space-y-4">
              {indexRows.map((row) => (
                <li
                  key={row.number}
                  className="group flex items-center justify-between border-b border-border-dark pb-3"
                >
                  <span className="text-body-lg font-medium text-white">{row.name}</span>
                  <div className="flex items-center gap-4">
                    <span className="text-body-sm text-paper-muted">{row.number}</span>
                    <motion.span whileHover={{ x: 4 }} className="text-accent">
                      <ArrowRight size={16} />
                    </motion.span>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <ul className="mt-10 space-y-3 border-t border-border-dark pt-6">
          {listingRows.map((row) => (
            <li key={row} className="group flex items-center justify-between">
              <span className="text-body-md text-white">{row}</span>
              <motion.span whileHover={{ x: 4 }} className="text-accent">
                <ArrowRight size={16} />
              </motion.span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
