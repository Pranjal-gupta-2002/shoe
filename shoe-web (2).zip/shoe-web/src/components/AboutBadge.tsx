import { motion } from "framer-motion";
import Button from "./primitives/Button";
import PhotoBlock from "./primitives/PhotoBlock";
import GlowBackdrop from "./primitives/GlowBackdrop";

export default function AboutBadge() {
  return (
    <section id="about" className="relative overflow-hidden bg-bg px-4 py-16 md:px-16 md:py-24">
      <GlowBackdrop />
      <div className="relative mx-auto grid max-w-5xl grid-cols-2 items-center gap-4 md:gap-8">
        <PhotoBlock aspect="portrait" shoe={3} accent="green" interactive />
        <PhotoBlock aspect="portrait" shoe={4} accent="coral" interactive />
      </div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: false, amount: 0.3 }}
        transition={{ duration: 0.5 }}
        className="absolute left-1/2 top-1/2 flex h-56 w-56 -translate-x-1/2 -translate-y-1/2 flex-col items-center justify-center rounded-full bg-white p-6 text-center shadow-float"
      >
        <h3 className="font-display text-display-sm font-bold text-text">About Us</h3>
        <p className="mt-2 text-body-xs text-text-muted">
          We believe shoes are more than accessories — they're a statement of style, comfort,
          and confidence.
        </p>
        <div className="mt-3">
          <Button size="sm" variant="accent">
            Explore
          </Button>
        </div>
      </motion.div>
    </section>
  );
}
