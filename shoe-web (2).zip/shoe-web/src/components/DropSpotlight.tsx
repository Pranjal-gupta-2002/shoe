import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { useRef } from "react";
import Button from "./primitives/Button";
import PhotoBlock from "./primitives/PhotoBlock";
import GlowBackdrop from "./primitives/GlowBackdrop";

export default function DropSpotlight() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [-24, 24]);

  return (
    <section id="drops" ref={ref} className="relative overflow-hidden bg-bg px-4 py-12 md:px-16 md:py-24">
      <GlowBackdrop />
      <div className="relative mx-auto grid max-w-6xl grid-cols-1 items-center gap-10 md:grid-cols-2">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: false, amount: 0.4 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="font-display text-[36px] font-black uppercase leading-[40px] text-white md:text-display-lg">
            Your Next Level Kicks Just Dropped
          </h2>
          <p className="mt-4 max-w-md text-body-md text-paper-muted">
            Designed for those who move different. Sleek design, premium comfort, and a fearless
            vibe that defines your generation.
          </p>
          <div className="mt-6">
            <Button
              variant="inverse"
              icon={<ArrowRight size={18} className="transition-transform group-hover:translate-x-1" />}
            >
              Shop The Drop
            </Button>
          </div>
        </motion.div>

        <motion.div style={{ y }} className="grid grid-cols-2 gap-4">
          <PhotoBlock aspect="square" shoe={1} accent="gold" interactive />
          <PhotoBlock aspect="square" shoe={3} accent="coral" interactive />
          <PhotoBlock aspect="square" shoe={4} accent="green" interactive />
          <PhotoBlock aspect="square" shoe={2} accent="gold" interactive />
        </motion.div>
      </div>
    </section>
  );
}
