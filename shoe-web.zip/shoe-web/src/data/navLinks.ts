export interface NavLink {
  label: string;
  href: string;
}

export const navLinks: NavLink[] = [
  { label: "Home", href: "#home" },
  { label: "Drops", href: "#drops" },
  { label: "Catalog", href: "#catalog" },
  { label: "About", href: "#about" },
];
