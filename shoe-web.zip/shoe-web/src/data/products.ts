export type ProductCategory =
  | "Fresh Fits"
  | "Heavy Heat"
  | "Go Flow"
  | "Slide Zone"
  | "Core Edit";

export interface Product {
  id: string;
  name: string;
  price: number;
  category: ProductCategory;
  rating: number;
}

export const categories: ProductCategory[] = [
  "Fresh Fits",
  "Heavy Heat",
  "Go Flow",
  "Slide Zone",
  "Core Edit",
];

export const products: Product[] = [
  { id: "p1", name: "Nova Strike", price: 220, category: "Fresh Fits", rating: 4.8 },
  { id: "p2", name: "Ember Runner", price: 180, category: "Heavy Heat", rating: 4.5 },
  { id: "p3", name: "Vortex Flow", price: 250, category: "Go Flow", rating: 4.9 },
  { id: "p4", name: "Slide King", price: 140, category: "Slide Zone", rating: 4.3 },
  { id: "p5", name: "Core Classic", price: 165, category: "Core Edit", rating: 4.6 },
  { id: "p6", name: "Blaze Edge", price: 230, category: "Heavy Heat", rating: 4.7 },
  { id: "p7", name: "Drift Sole", price: 195, category: "Go Flow", rating: 4.4 },
  { id: "p8", name: "Street Nova", price: 210, category: "Fresh Fits", rating: 4.8 },
  { id: "p9", name: "Retro Pulse", price: 175, category: "Core Edit", rating: 4.5 },
];

export const signatureShoes = [
  "Street Nova",
  "NeoWalk",
  "Retro Pulse",
  "Vortex Run",
  "KickCraft",
  "EdgeLine",
];

const accentCycle = ["green", "gold", "coral"] as const;

export function getProductVisual(id: string) {
  const seed = id.charCodeAt(id.length - 1);
  return {
    shoe: ((seed % 4) + 1) as 1 | 2 | 3 | 4,
    accent: accentCycle[seed % accentCycle.length],
  };
}
