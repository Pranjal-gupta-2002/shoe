export interface Testimonial {
  id: string;
  name: string;
  quote: string;
  rating: number;
}

export const testimonials: Testimonial[] = [
  {
    id: "t1",
    name: "Rahul S.",
    quote: "Great quality boots, fast shipping and excellent customer service!",
    rating: 5,
  },
  {
    id: "t2",
    name: "Ananya K.",
    quote: "Authentic products and amazing packaging. Highly recommend!",
    rating: 5,
  },
  {
    id: "t3",
    name: "Vikram M.",
    quote: "Best place to get football boots online. Super fast delivery.",
    rating: 5,
  },
];
