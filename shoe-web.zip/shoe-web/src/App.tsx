import { DripBagProvider } from "./context/DripBagContext";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Ticker from "./components/Ticker";
import DropSpotlight from "./components/DropSpotlight";
import CampaignBanner from "./components/CampaignBanner";
import LifestyleCollage from "./components/LifestyleCollage";
import SignatureCarousel from "./components/SignatureCarousel";
import ProductCatalog from "./components/ProductCatalog";
import InlinePhotoStatement from "./components/InlinePhotoStatement";
import AboutBadge from "./components/AboutBadge";
import LookbookWheel from "./components/LookbookWheel";
import Testimonials from "./components/Testimonials";
import EditorialIndex from "./components/EditorialIndex";
import CtaFooterPanel from "./components/CtaFooterPanel";

function App() {
  return (
    <DripBagProvider>
      <Navbar />
      <Hero />
      <Ticker />
      <DropSpotlight />
      <CampaignBanner />
      <LifestyleCollage />
      <SignatureCarousel />
      <ProductCatalog />
      <InlinePhotoStatement />
      <AboutBadge />
      <LookbookWheel />
      <Testimonials />
      <EditorialIndex />
      <CtaFooterPanel />
    </DripBagProvider>
  );
}

export default App;
