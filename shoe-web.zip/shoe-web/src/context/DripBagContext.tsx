import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from "react";

export interface DripBagItem {
  productId: string;
  quantity: number;
}

interface DripBagContextValue {
  items: DripBagItem[];
  count: number;
  add: (productId: string) => void;
}

const DripBagContext = createContext<DripBagContextValue | null>(null);

export function DripBagProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<DripBagItem[]>([]);

  const add = useCallback((productId: string) => {
    setItems((prev) => {
      const existing = prev.find((item) => item.productId === productId);
      if (existing) {
        return prev.map((item) =>
          item.productId === productId ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { productId, quantity: 1 }];
    });
  }, []);

  const count = useMemo(() => items.reduce((sum, item) => sum + item.quantity, 0), [items]);

  const value = useMemo(() => ({ items, count, add }), [items, count, add]);

  return <DripBagContext.Provider value={value}>{children}</DripBagContext.Provider>;
}

export function useDripBag() {
  const ctx = useContext(DripBagContext);
  if (!ctx) throw new Error("useDripBag must be used within a DripBagProvider");
  return ctx;
}
