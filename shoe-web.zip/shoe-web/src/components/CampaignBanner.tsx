import { motion } from "framer-motion";
import PhotoBlock from "./primitives/PhotoBlock";

export default function CampaignBanner() {
  return (
    <section className="relative bg-ink px-4 py-12 md:px-16 md:py-24">
      <div className="relative mx-auto max-w-6xl">
        <PhotoBlock
          aspect="landscape"
          dark
          shoe={2}
          accent="gold"
          className="h-[420px] w-full md:h-[520px]"
        />
        <motion.h2
          initial={{ opacity: 0, scale: 0.94 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: false, amount: 0.5 }}
          transition={{ duration: 0.6 }}
          className="absolute left-6 top-8 font-display text-[64px] font-black uppercase leading-none text-white md:left-12 md:top-12 md:text-[120px]"
        >
          ELEVATE
        </motion.h2>
        <p className="absolute bottom-20 left-6 max-w-xs text-body-sm text-paper-muted md:bottom-24 md:left-12">
          The latest collection is here. Bold looks, wild comfort, and limited-time offers that
          hit different. Step up your game before it's gone.
        </p>
        <span className="absolute bottom-6 right-6 rounded-pill border border-accent px-4 py-1.5 text-body-xs font-medium text-accent md:right-12">
          Drop 02
        </span>
      </div>
    </section>
  );
}
