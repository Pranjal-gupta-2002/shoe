const TAGLINE = "FRESH DROPS WEEKLY";

export default function Ticker() {
  const items = Array.from({ length: 8 }).map((_, i) => (
    <span key={i} className="mx-6 font-display text-lg font-bold uppercase tracking-wide text-accent">
      {TAGLINE} <span className="mx-6 text-white/30">•</span>
    </span>
  ));

  return (
    <div className="overflow-hidden bg-ink py-4">
      <div className="marquee-track">
        <div className="flex">{items}</div>
        <div className="flex">{items}</div>
      </div>
    </div>
  );
}
