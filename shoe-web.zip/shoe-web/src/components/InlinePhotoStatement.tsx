import { motion } from "framer-motion";

function InlinePhoto({ delay }: { delay: number }) {
  return (
    <motion.span
      initial={{ scale: 0, opacity: 0 }}
      whileInView={{ scale: 1, opacity: 1 }}
      viewport={{ once: false, amount: 0.6 }}
      transition={{ delay, type: "spring", stiffness: 300 }}
      className="mx-1 inline-block h-10 w-10 translate-y-2 rounded-full bg-accent-soft align-middle"
    />
  );
}

export default function InlinePhotoStatement() {
  return (
    <section className="bg-bg px-4 py-16 text-center md:px-16 md:py-24">
      <p className="mx-auto max-w-4xl font-display text-[28px] font-black uppercase leading-tight text-white md:text-display-lg">
        WE <InlinePhoto delay={0.1} /> DON'T JUST MAKE SHOES, WE{" "}
        <InlinePhoto delay={0.3} /> CREATE EXPERIENCES
      </p>
    </section>
  );
}
