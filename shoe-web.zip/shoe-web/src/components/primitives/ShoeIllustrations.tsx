interface ShoeProps {
  accent?: string;
  className?: string;
}

const SOLE = "#F4F1EA";
const UPPER = "#1C1D22";

export function ShoeRunner({ accent = "var(--color-accent)", className = "" }: ShoeProps) {
  return (
    <svg viewBox="0 0 240 140" className={className} xmlns="http://www.w3.org/2000/svg">
      <path
        d="M14 118 C14 126 22 130 34 130 L188 130 C206 130 214 122 216 112 C217 106 212 102 204 103 C160 108 90 108 40 100 C24 97 14 106 14 118 Z"
        fill={SOLE}
        stroke="#00000022"
      />
      <path
        d="M20 100 C20 78 46 56 90 50 C124 46 158 52 182 68 C198 78 204 90 204 100 C204 106 198 110 188 110 L34 110 C24 110 20 106 20 100 Z"
        fill={UPPER}
      />
      <path
        d="M40 96 C70 108 130 108 178 88 C168 100 128 118 78 116 C56 114 44 106 40 96 Z"
        fill={accent}
      />
      <path d="M96 54 L118 50 L126 74 L104 78 Z" fill="#2A2B32" />
      {[0, 1, 2, 3].map((i) => (
        <line
          key={i}
          x1={100 + i * 10}
          y1={62 + i * 3}
          x2={112 + i * 10}
          y2={72 + i * 3}
          stroke="#F4F1EA"
          strokeWidth={2}
        />
      ))}
    </svg>
  );
}

export function ShoeCleat({ accent = "var(--color-accent)", className = "" }: ShoeProps) {
  return (
    <svg viewBox="0 0 240 140" className={className} xmlns="http://www.w3.org/2000/svg">
      <path
        d="M14 118 C14 126 22 130 34 130 L188 130 C206 130 214 122 216 112 C217 106 212 102 204 103 C160 108 90 108 40 100 C24 97 14 106 14 118 Z"
        fill={SOLE}
        stroke="#00000022"
      />
      {[50, 100, 150].map((x) => (
        <polygon key={x} points={`${x},129 ${x + 8},129 ${x + 4},138`} fill="#2A2B32" />
      ))}
      <path
        d="M20 100 C20 78 46 56 90 50 C124 46 158 52 182 68 C198 78 204 90 204 100 C204 106 198 110 188 110 L34 110 C24 110 20 106 20 100 Z"
        fill={UPPER}
      />
      <path d="M160 44 C172 40 182 44 186 54 L182 68 L164 74 Z" fill="#2A2B32" />
      <path
        d="M40 96 C70 108 130 108 178 88 C168 100 128 118 78 116 C56 114 44 106 40 96 Z"
        fill={accent}
      />
      <path d="M96 54 L118 50 L126 74 L104 78 Z" fill="#2A2B32" />
    </svg>
  );
}

export function ShoeLow({ accent = "var(--color-accent)", className = "" }: ShoeProps) {
  return (
    <svg viewBox="0 0 240 140" className={className} xmlns="http://www.w3.org/2000/svg">
      <path
        d="M16 116 C16 125 24 129 36 129 L184 129 C202 129 212 121 214 110 C215 104 210 101 202 102 C158 106 92 106 42 98 C26 96 16 105 16 116 Z"
        fill={SOLE}
        stroke="#00000022"
      />
      <path
        d="M24 98 C26 74 56 58 96 54 C132 51 164 58 186 74 C200 84 204 94 202 100 C202 106 196 108 186 108 L38 108 C28 108 22 104 24 98 Z"
        fill={UPPER}
      />
      <path d="M64 92 L188 68" stroke={accent} strokeWidth={10} strokeLinecap="round" />
      <path d="M92 56 L114 52 L120 76 L98 80 Z" fill="#2A2B32" />
    </svg>
  );
}

export function ShoeSlide({ accent = "var(--color-accent)", className = "" }: ShoeProps) {
  return (
    <svg viewBox="0 0 240 140" className={className} xmlns="http://www.w3.org/2000/svg">
      <path
        d="M20 110 C20 122 30 128 44 128 L196 128 C210 128 218 120 218 108 C218 100 208 96 196 98 L44 98 C30 98 20 100 20 110 Z"
        fill={SOLE}
        stroke="#00000022"
      />
      <path
        d="M60 96 C60 78 80 66 128 66 C176 66 196 78 196 96 L196 108 L60 108 Z"
        fill={accent}
      />
    </svg>
  );
}

export const shoeVariants = [ShoeRunner, ShoeCleat, ShoeLow, ShoeSlide];
