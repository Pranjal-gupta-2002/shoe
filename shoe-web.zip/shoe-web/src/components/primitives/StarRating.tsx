import { motion } from "framer-motion";
import { Star } from "lucide-react";

interface StarRatingProps {
  rating: number;
  size?: number;
  stagger?: boolean;
}

export default function StarRating({ rating, size = 14, stagger = false }: StarRatingProps) {
  const rounded = Math.round(rating);
  return (
    <div className="flex items-center gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <motion.span
          key={i}
          initial={stagger ? { scale: 0, opacity: 0 } : undefined}
          whileInView={stagger ? { scale: 1, opacity: 1 } : undefined}
          viewport={{ once: false, amount: 0.6 }}
          transition={{ delay: i * 0.05, type: "spring", stiffness: 300 }}
        >
          <Star
            size={size}
            className={i < rounded ? "fill-gold text-gold" : "fill-none text-border-subtle"}
          />
        </motion.span>
      ))}
    </div>
  );
}
