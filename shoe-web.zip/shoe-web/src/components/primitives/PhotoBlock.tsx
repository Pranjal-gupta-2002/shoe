import { shoeVariants } from "./ShoeIllustrations";

interface PhotoBlockProps {
  aspect?: "square" | "portrait" | "landscape";
  label?: string;
  tilt?: number;
  dark?: boolean;
  shoe?: 1 | 2 | 3 | 4;
  accent?: "green" | "gold" | "coral";
  className?: string;
}

const aspectClasses: Record<string, string> = {
  square: "aspect-square",
  portrait: "aspect-[3/4]",
  landscape: "aspect-[4/3]",
};

const accentColors: Record<string, string> = {
  green: "var(--color-accent)",
  gold: "var(--color-gold)",
  coral: "var(--color-coral)",
};

export default function PhotoBlock({
  aspect = "square",
  label,
  tilt = 0,
  dark = false,
  shoe = 1,
  accent = "green",
  className = "",
}: PhotoBlockProps) {
  const Shoe = shoeVariants[shoe - 1];

  return (
    <div
      style={tilt ? { transform: `rotate(${tilt}deg)` } : undefined}
      className={`relative overflow-hidden rounded-card ${aspectClasses[aspect]} ${
        dark ? "bg-ink-soft" : "bg-tile"
      } ${className}`}
    >
      {/* Custom illustrated placeholder — TODO: swap for real product photography */}
      <div
        className="absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage:
            "radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)",
          backgroundSize: "12px 12px",
        }}
      />
      <Shoe
        accent={accentColors[accent]}
        className="absolute left-1/2 top-1/2 h-[65%] w-[80%] -translate-x-1/2 -translate-y-1/2 drop-shadow-[0_8px_16px_rgba(0,0,0,0.25)]"
      />
      {label && (
        <span className="absolute bottom-3 left-3 rounded-pill bg-white/95 px-3 py-1 text-body-xs font-medium text-text shadow-float">
          {label}
        </span>
      )}
    </div>
  );
}
