import { motion } from "framer-motion";
import { type ReactNode, useRef } from "react";

interface ButtonProps {
  variant?: "primary" | "accent" | "outline" | "inverse";
  size?: "sm" | "md" | "lg";
  icon?: ReactNode;
  magnetic?: boolean;
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  className?: string;
  children: ReactNode;
}

const variantClasses: Record<string, string> = {
  primary: "bg-ink text-white hover:bg-ink/90",
  accent: "border border-accent text-accent hover:bg-accent-soft",
  outline: "border border-border-subtle text-text hover:border-accent hover:text-accent",
  inverse: "bg-white text-ink hover:bg-white/90",
};

const sizeClasses: Record<string, string> = {
  sm: "px-4 py-2 text-body-xs",
  md: "px-6 py-3 text-body-sm",
  lg: "px-8 py-4 text-body-md",
};

export default function Button({
  variant = "primary",
  size = "md",
  icon,
  magnetic = false,
  onClick,
  className = "",
  children,
}: ButtonProps) {
  const ref = useRef<HTMLButtonElement>(null);

  function handleMouseMove(e: React.MouseEvent<HTMLButtonElement>) {
    if (!magnetic || !ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;
    ref.current.style.transform = `translate(${x * 0.15}px, ${y * 0.25}px)`;
  }

  function handleMouseLeave() {
    if (!magnetic || !ref.current) return;
    ref.current.style.transform = "translate(0, 0)";
  }

  return (
    <motion.button
      ref={ref}
      type="button"
      onClick={onClick}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      whileHover={{ scale: 1.04 }}
      whileTap={{ scale: 0.96 }}
      transition={{ type: "spring", stiffness: 400, damping: 20 }}
      className={`inline-flex items-center gap-2 rounded-pill font-body font-medium transition-colors duration-200 ${variantClasses[variant]} ${sizeClasses[size]} ${className}`}
    >
      {children}
      {icon}
    </motion.button>
  );
}
