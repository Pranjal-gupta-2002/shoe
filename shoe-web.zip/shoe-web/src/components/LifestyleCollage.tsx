import { motion } from "framer-motion";
import Button from "./primitives/Button";
import PhotoBlock from "./primitives/PhotoBlock";

const tiles = [
  { aspect: "portrait" as const, shoe: 3 as const, accent: "coral" as const, className: "col-span-1 row-span-2" },
  { aspect: "square" as const, shoe: 4 as const, accent: "green" as const, className: "col-span-1" },
  { aspect: "square" as const, shoe: 1 as const, accent: "gold" as const, className: "col-span-1" },
];

export default function LifestyleCollage() {
  return (
    <section className="bg-bg px-4 py-12 md:px-16 md:py-24">
      <div className="mx-auto grid max-w-6xl grid-cols-1 items-center gap-10 md:grid-cols-2">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: false, amount: 0.3 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="font-display text-[32px] font-black uppercase leading-[36px] text-white md:text-display-md">
            Not Just Shoes, A Lifestyle
          </h2>
          <p className="mt-4 max-w-sm text-body-md text-paper-muted">
            Every pair is designed to match your grind, your goals, and your style — comfort that
            keeps up with everything you do.
          </p>
          <div className="mt-6">
            <Button variant="accent">Live The Style</Button>
          </div>
        </motion.div>

        <div className="grid grid-cols-2 gap-4">
          {tiles.map((tile, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.92 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: false, amount: 0.3 }}
              transition={{ delay: i * 0.15, duration: 0.5 }}
              className={tile.className}
            >
              <PhotoBlock aspect={tile.aspect} shoe={tile.shoe} accent={tile.accent} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
