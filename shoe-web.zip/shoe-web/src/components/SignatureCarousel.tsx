import { useRef, useState } from "react";
import SectionHeading from "./primitives/SectionHeading";
import PhotoBlock from "./primitives/PhotoBlock";
import { signatureShoes } from "../data/products";

export default function SignatureCarousel() {
  const trackRef = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);

  function handleScroll() {
    const el = trackRef.current;
    if (!el) return;
    const cardWidth = el.scrollWidth / signatureShoes.length;
    const index = Math.round(el.scrollLeft / cardWidth);
    setActive(Math.min(signatureShoes.length - 1, Math.max(0, index)));
  }

  return (
    <section className="bg-bg px-4 py-12 md:px-16 md:py-24">
      <div className="mx-auto max-w-6xl">
        <SectionHeading eyebrow={`${active + 1} / ${signatureShoes.length}`}>
          Explore Our Signature Shoes
        </SectionHeading>

        <div
          ref={trackRef}
          onScroll={handleScroll}
          className="no-scrollbar mt-8 flex snap-x snap-mandatory gap-5 overflow-x-auto pb-4"
        >
          {signatureShoes.map((name, i) => (
            <div key={name} className="w-56 flex-shrink-0 snap-start">
              <PhotoBlock
                aspect="portrait"
                label={name}
                shoe={((i % 4) + 1) as 1 | 2 | 3 | 4}
                accent={(["green", "gold", "coral"] as const)[i % 3]}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
