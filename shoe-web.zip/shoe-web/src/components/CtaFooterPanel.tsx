import { motion } from "framer-motion";
import { Globe, MessageCircle, Share2 } from "lucide-react";
import Button from "./primitives/Button";

const footerColumns = [
  { heading: "Menu", links: ["About", "Industries", "Product", "Categories"] },
  { heading: "Shop", links: ["Fresh Fits", "Heavy Heat", "Go Flow", "Core Edit"] },
  { heading: "Support", links: ["Contact", "FAQ", "Shipping", "Returns"] },
];

const socials = [Globe, MessageCircle, Share2];

export default function CtaFooterPanel() {
  return (
    <section className="bg-bg px-4 py-12 md:px-16 md:py-24">
      <div className="mx-auto max-w-6xl rounded-panel bg-ink p-8 text-white md:p-14">
        <div className="flex flex-col items-start justify-between gap-6 border-b border-white/10 pb-10 md:flex-row md:items-center">
          <h2 className="font-display text-[36px] font-black uppercase leading-tight md:text-display-lg">
            Ready To Upgrade Your Game?
          </h2>
          <Button variant="inverse" magnetic>
            Get In Touch
          </Button>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-8 md:grid-cols-4">
          <div>
            <span className="font-display text-2xl font-black uppercase">Bootsempire</span>
            <p className="mt-3 text-body-sm text-paper-muted">
              123 Pitch Street, Sport City
              <br />
              hello@bootsempire.com
            </p>
            <div className="mt-4 flex gap-3">
              {socials.map((Icon, i) => (
                <motion.a
                  key={i}
                  href="#"
                  whileHover={{ scale: 1.15, rotate: 8 }}
                  className="rounded-full bg-white/10 p-2 text-white"
                >
                  <Icon size={16} />
                </motion.a>
              ))}
            </div>
          </div>

          {footerColumns.map((col) => (
            <div key={col.heading}>
              <h4 className="text-body-sm font-semibold uppercase tracking-wide text-white">
                {col.heading}
              </h4>
              <ul className="mt-3 space-y-2">
                {col.links.map((link) => (
                  <li key={link}>
                    <a href="#" className="text-body-sm text-paper-muted hover:text-accent">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-3 border-t border-white/10 pt-6 text-body-xs text-paper-muted md:flex-row">
          <span>© 2026 Bootsempire. All rights reserved.</span>
          <div className="flex gap-4">
            <a href="#" className="hover:text-accent">Terms & Conditions</a>
            <a href="#" className="hover:text-accent">Privacy Policy</a>
          </div>
        </div>
      </div>
    </section>
  );
}
