import { motion } from "framer-motion";
import { Heart } from "lucide-react";
import { useState } from "react";
import Button from "./primitives/Button";
import PhotoBlock from "./primitives/PhotoBlock";
import StarRating from "./primitives/StarRating";
import { getProductVisual, type Product } from "../data/products";
import { useDripBag } from "../context/DripBagContext";

interface ProductCardProps {
  product: Product;
  onQuickView: (product: Product) => void;
}

export default function ProductCard({ product, onQuickView }: ProductCardProps) {
  const [wishlisted, setWishlisted] = useState(false);
  const { add } = useDripBag();
  const { shoe, accent } = getProductVisual(product.id);

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: false, amount: 0.3 }}
      whileHover={{ y: -6, rotate: -1 }}
      transition={{ duration: 0.4 }}
      className="cursor-pointer rounded-card border border-border-subtle bg-white p-4"
      onClick={() => onQuickView(product)}
    >
      <div className="relative">
        <PhotoBlock aspect="square" shoe={shoe} accent={accent} />
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            setWishlisted((w) => !w);
          }}
          aria-label="Toggle wishlist"
          className="absolute right-2 top-2 rounded-full bg-white/90 p-2"
        >
          <Heart size={16} className={wishlisted ? "fill-coral text-coral" : "text-text-muted"} />
        </button>
      </div>
      <h3 className="mt-3 font-display text-display-sm font-bold text-text">{product.name}</h3>
      <div className="mt-1 flex items-center justify-between">
        <span className="text-body-md font-semibold text-text">${product.price}</span>
        <StarRating rating={product.rating} />
      </div>
      <Button
        size="sm"
        className="mt-3 w-full justify-center"
        onClick={(e) => {
          e.stopPropagation();
          add(product.id);
        }}
      >
        Add to Drip Bag
      </Button>
    </motion.div>
  );
}
