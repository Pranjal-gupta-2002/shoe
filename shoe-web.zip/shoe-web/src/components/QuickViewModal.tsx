import Button from "./primitives/Button";
import Modal from "./primitives/Modal";
import PhotoBlock from "./primitives/PhotoBlock";
import StarRating from "./primitives/StarRating";
import { getProductVisual, type Product } from "../data/products";
import { useDripBag } from "../context/DripBagContext";

interface QuickViewModalProps {
  product: Product | null;
  onClose: () => void;
}

export default function QuickViewModal({ product, onClose }: QuickViewModalProps) {
  const { add } = useDripBag();

  return (
    <Modal open={!!product} onClose={onClose}>
      {product && (
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <PhotoBlock aspect="square" {...getProductVisual(product.id)} />
          <div>
            <h3 className="font-display text-display-md font-bold text-text">{product.name}</h3>
            <p className="mt-1 text-body-sm text-text-muted">{product.category}</p>
            <div className="mt-3 flex items-center gap-3">
              <span className="text-body-lg font-semibold text-text">${product.price}</span>
              <StarRating rating={product.rating} />
            </div>

            <div className="mt-6 flex gap-3">
              <select className="flex-1 rounded-pill border border-border-subtle px-4 py-2 text-body-sm text-text">
                <option>Size</option>
                <option>UK 7</option>
                <option>UK 8</option>
                <option>UK 9</option>
                <option>UK 10</option>
              </select>
              <select className="flex-1 rounded-pill border border-border-subtle px-4 py-2 text-body-sm text-text">
                <option>Color</option>
                <option>Black</option>
                <option>White</option>
                <option>Green</option>
              </select>
            </div>

            <Button
              className="mt-6 w-full justify-center"
              onClick={() => {
                add(product.id);
                onClose();
              }}
            >
              Add to Drip Bag
            </Button>
          </div>
        </div>
      )}
    </Modal>
  );
}
