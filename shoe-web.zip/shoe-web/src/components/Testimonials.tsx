import { motion } from "framer-motion";
import SectionHeading from "./primitives/SectionHeading";
import StarRating from "./primitives/StarRating";
import { testimonials } from "../data/testimonials";

export default function Testimonials() {
  return (
    <section className="bg-bg px-4 py-12 md:px-16 md:py-24">
      <div className="mx-auto max-w-6xl">
        <SectionHeading align="center" className="mx-auto">
          Every Pair Tells A Story — Here's Theirs
        </SectionHeading>

        <div className="mt-10 grid grid-cols-1 gap-6 md:grid-cols-3">
          {testimonials.map((t, i) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: false, amount: 0.3 }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              className="rounded-card border border-border-subtle bg-white p-6"
            >
              <div className="h-10 w-10 rounded-full bg-accent-soft" />
              <div className="mt-3">
                <StarRating rating={t.rating} stagger />
              </div>
              <p className="mt-3 text-body-md text-text">{t.quote}</p>
              <p className="mt-3 text-body-sm text-text-muted">{t.name}</p>
            </motion.div>
          ))}
        </div>

        <p className="mt-8 text-center text-body-sm text-paper-muted">
          Trusted By 100+ Customers
        </p>
      </div>
    </section>
  );
}
