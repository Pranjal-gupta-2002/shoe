import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import PhotoBlock from "./primitives/PhotoBlock";
import Button from "./primitives/Button";
import StarRating from "./primitives/StarRating";
import { useDripBag } from "../context/DripBagContext";

const headlineWords = ["FOOTWEAR", "FOR", "EVERY", "OCCASION"];

const container = {
  hidden: {},
  show: {
    transition: { staggerChildren: 0.08 },
  },
};

const wordVariant = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

export default function Hero() {
  const { add } = useDripBag();

  return (
    <section
      id="home"
      className="relative flex min-h-screen items-center overflow-hidden pt-24"
      style={{
        background:
          "linear-gradient(105deg, var(--color-ink-deep) 48%, var(--color-ink-soft) 48%)",
      }}
    >
      {/* Ghost type layer */}
      <span
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-1/2 z-0 -translate-x-1/2 -translate-y-1/2 select-none whitespace-nowrap font-display text-[180px] font-black uppercase text-accent opacity-10 md:text-[260px]"
      >
        DROP
      </span>

      <div className="relative z-10 mx-auto grid w-full max-w-6xl grid-cols-1 items-center gap-12 px-4 md:grid-cols-2 md:px-16">
        {/* Left: copy */}
        <div>
          <motion.h1
            variants={container}
            initial="hidden"
            whileInView="show"
            viewport={{ once: false, amount: 0.5 }}
            className="font-display text-[44px] font-black uppercase leading-[48px] text-white md:text-display-xl"
          >
            {headlineWords.map((word) => (
              <motion.span key={word} variants={wordVariant} className="mr-3 inline-block">
                {word}
              </motion.span>
            ))}
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: false, amount: 0.5 }}
            transition={{ delay: 0.6, duration: 0.5 }}
            className="mt-5 max-w-md text-body-lg text-paper-muted"
          >
            Discover boots that combine elegance, comfort, and durability. Built for every pitch,
            every play, every occasion.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: false, amount: 0.5 }}
            transition={{ delay: 0.8, duration: 0.5 }}
            className="mt-8"
          >
            <Button variant="inverse" magnetic icon={<ArrowRight size={18} />}>
              Shop Now
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: false, amount: 0.5 }}
            transition={{ delay: 1, duration: 0.5 }}
            className="mt-10 flex flex-wrap items-center gap-4"
          >
            <div className="flex -space-x-3">
              {[0, 1, 2].map((i) => (
                <div
                  key={i}
                  className="h-9 w-9 rounded-full border-2 border-ink-deep bg-accent-soft"
                />
              ))}
            </div>
            <span className="text-body-sm text-paper-muted">1,000+ Beta Users</span>
            <span className="flex items-center gap-1.5 rounded-pill bg-white/10 px-3 py-1.5 text-body-xs text-white">
              <StarRating rating={4.8} size={12} /> 4.8 Trustpilot
            </span>
          </motion.div>
        </div>

        {/* Right: product photo + floating tags */}
        <div className="relative flex justify-center">
          <motion.div
            animate={{ y: [0, -8, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className="relative w-full max-w-sm"
          >
            <PhotoBlock aspect="portrait" dark shoe={2} className="shadow-glow-accent" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: false, amount: 0.5 }}
            transition={{ delay: 1.1, duration: 0.5 }}
            className="absolute left-0 top-6 hidden w-40 rounded-card bg-white p-3 shadow-float md:block"
          >
            <p className="text-body-xs font-semibold text-text">Boot Lovers</p>
            <p className="mt-1 text-[11px] leading-snug text-text-muted">
              Crafted for those who never settle for less.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: false, amount: 0.5 }}
            transition={{ delay: 1.3, duration: 0.5 }}
            className="absolute -right-2 bottom-24 hidden w-40 rounded-card bg-white p-3 shadow-float md:block"
          >
            <p className="text-body-xs font-semibold text-text">Elite Grade</p>
            <p className="mt-1 text-[11px] leading-snug text-text-muted">
              Sourced from top brands worldwide.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: false, amount: 0.5 }}
            transition={{ delay: 1.4, duration: 0.5 }}
            className="absolute -bottom-6 left-4 flex items-center gap-3 rounded-card bg-white p-3 shadow-float"
          >
            <span className="text-body-md font-semibold text-text">$220</span>
            <Button size="sm" onClick={() => add("p1")}>
              Add to Drip Bag
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
